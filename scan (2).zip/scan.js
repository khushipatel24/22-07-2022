let name=prompt("How Are You");
document.write(name);




